# Java Full-Stack Student Management App

## Stack
Java 17, Spring Boot, Spring Data JPA/Hibernate, MySQL,
HTML, CSS, JavaScript, Maven.

## Setup
1. Install JDK 17+, Maven, and MySQL.
2. Run `database.sql` in MySQL.
3. Open `src/main/resources/application.properties`.
4. Replace `YOUR_MYSQL_PASSWORD` with your MySQL password.
5. Run: `mvn spring-boot:run`
6. Open: `http://localhost:8080`

## REST APIs
GET `/api/students`
GET `/api/students/{id}`
POST `/api/students`
PUT `/api/students/{id}`
DELETE `/api/students/{id}`

This project uses JPA for database access. Learn direct JDBC separately
to understand the lower-level database connection concepts.
