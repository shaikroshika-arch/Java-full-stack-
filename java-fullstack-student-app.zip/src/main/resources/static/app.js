const API="/api/students";
async function load(){const r=await fetch(API);const data=await r.json();document.getElementById("rows").innerHTML=data.map(s=>`<tr><td>${s.id}</td><td>${s.name}</td><td>${s.age}</td><td>${s.email}</td><td><button onclick="removeStudent(${s.id})">Delete</button></td></tr>`).join("");}
document.getElementById("form").addEventListener("submit",async e=>{e.preventDefault();await fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:name.value,age:Number(age.value),email:email.value})});e.target.reset();load();});
async function removeStudent(id){await fetch(`${API}/${id}`,{method:"DELETE"});load()} load();
