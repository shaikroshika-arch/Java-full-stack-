package com.example.studentapp;
import jakarta.persistence.*;

@Entity
@Table(name="students")
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Integer age;
    private String email;

    public Student() {}
    public Student(String name, Integer age, String email) {
        this.name=name; this.age=age; this.email=email;
    }
    public Long getId(){ return id; }
    public String getName(){ return name; }
    public void setName(String name){ this.name=name; }
    public Integer getAge(){ return age; }
    public void setAge(Integer age){ this.age=age; }
    public String getEmail(){ return email; }
    public void setEmail(String email){ this.email=email; }
}
