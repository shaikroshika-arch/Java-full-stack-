CREATE DATABASE IF NOT EXISTS college;
USE college;
-- Spring Boot/JPA creates the students table automatically.
